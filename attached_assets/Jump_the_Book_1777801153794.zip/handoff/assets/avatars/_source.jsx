// avatars.jsx — 10 geometric bunny avatars for "Pick your bunny"
// Flat vector, on-brand. No faces beyond minimal eyes/nose so they read as a set.
// Each is a self-contained 200×200 SVG.

const AvBase = ({ bg, children }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" width="200" height="200">
    <rect width="200" height="200" rx="100" fill={bg}/>
    {children}
  </svg>
);

// Body shapes shared by all avatars
const Bunny = ({ fur = '#EDE6D3', inner = '#C9A96A', eye = '#08080B', accessory }) => (
  <g>
    {/* Ears */}
    <rect x="62" y="36" width="22" height="78" rx="11" fill={fur} transform="rotate(-10 73 75)"/>
    <rect x="116" y="36" width="22" height="78" rx="11" fill={fur} transform="rotate(10 127 75)"/>
    <rect x="68" y="48" width="10" height="56" rx="5" fill={inner} transform="rotate(-10 73 76)"/>
    <rect x="122" y="48" width="10" height="56" rx="5" fill={inner} transform="rotate(10 127 76)"/>
    {/* Head */}
    <circle cx="100" cy="120" r="50" fill={fur}/>
    {/* Eyes */}
    <circle cx="82" cy="116" r="4" fill={eye}/>
    <circle cx="118" cy="116" r="4" fill={eye}/>
    {/* Nose */}
    <path d="M100 130 L94 138 L106 138 Z" fill={inner}/>
    {accessory}
  </g>
);

const Avatars = {
  cream:    <AvBase bg="#1E1F28"><Bunny fur="#EDE6D3" inner="#C9A96A"/></AvBase>,
  gold:     <AvBase bg="#08080B"><Bunny fur="#C9A96A" inner="#6B552A" eye="#08080B"/></AvBase>,
  rose:     <AvBase bg="#3D1A2A"><Bunny fur="#E8B86A" inner="#A04A6B"/></AvBase>,
  midnight: <AvBase bg="#0F1A2E"><Bunny fur="#A8B5D9" inner="#3C4F7A" eye="#08080B"/></AvBase>,
  forest:   <AvBase bg="#0E1A14"><Bunny fur="#9CC5A0" inner="#1E5128"/></AvBase>,
  ember:    <AvBase bg="#1F0F0A"><Bunny fur="#E2A06B" inner="#7A3322"/></AvBase>,
  ink:      <AvBase bg="#16171E"><Bunny fur="#2A2B36" inner="#C9A96A" eye="#C9A96A"/></AvBase>,
  paper:    <AvBase bg="#EDE6D3"><Bunny fur="#1E1F28" inner="#C9A96A" eye="#EDE6D3"/></AvBase>,
  mauve:    <AvBase bg="#2D2438"><Bunny fur="#C9A4A4" inner="#7A6A8C"/></AvBase>,
  sage:     <AvBase bg="#1A2E2A"><Bunny fur="#C4B89B" inner="#5C8A7E"/></AvBase>,
};
